@extends('front.layout')
@section('content')
    
    <section id="services">
      <div class="container" style="min-height: 54vh">
        <div class="section-header">
          <h2>{{ $article->judul }}</h2>
          <article class="col-sm-8">
            {!! $article->isi !!}
          </article>
        </div>
      </div>
    </section>
  </main>
@endsection
@section('custom-script')
<script type="text/javascript">
$('select[name=lokasi]').on('change', function(){
  let id_lokasi = $(this).val();
  $.get('{{ url("ajax/to") }}/'+id_lokasi).success(function(data){
    $('select[name=to]').html('');
    $('select[name=to]').append('<option>-- pilih tanggal pelaksanaan --</option>');
    for(var i = 0; i < data.length; i++){
      $('select[name=to]').append('<option value="'+data[i].id+'">'+data[i].tanggal_pelaksanaan+"</option>");
    }
  })
});
$('select[name=to]').on('change', function(){
  let id_lokasi = $(this).val();
  $.get('{{ url("ajax/product") }}/'+id_lokasi).success(function(data){
    $('select[name=product]').html('');
    $('select[name=product]').append('<option>-- pilih paket pendaftaran --</option>');
    for(var i = 0; i < data.length; i++){
      $('select[name=product]').append('<option value="'+data[i].id+'">'+data[i].name+"</option>");
    }
  })
});
</script>
@endsection