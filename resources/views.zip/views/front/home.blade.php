@extends('front.layout')
@section('content')
  <!--==========================
    Intro Section
  ============================-->
  <section id="intro">

    <div class="intro-content">
      <!-- <h2>
        Try Out <span>SBMPTN 2019</span>
        <br>By <span>Masuk PTN</span>
      </h2>
      <div>
        <a href="#about" class="btn-get-started scrollto">Daftar Sekarang</a>
        <a href="#portfolio" class="btn-projects scrollto">Alur Pendaftaran</a>
      </div> -->
    </div>

    <div id="intro-carousel" class="owl-carousel" >
      <div class="item" style="background-image: url('img/intro-carousel/1.jpg');"></div>
      <div class="item" style="background-image: url('img/intro-carousel/2.jpg');"></div>
      <div class="item" style="background-image: url('img/intro-carousel/3.jpg');"></div>
      <div class="item" style="background-image: url('img/intro-carousel/4.jpg');"></div>
      <div class="item" style="background-image: url('img/intro-carousel/5.jpg');"></div>
    </div>

  </section><!-- #intro -->

  <main id="main">

    <!--==========================
      About Section
    ============================-->
    <section id="about" class="wow fadeInUp">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 about-img">
            <img src="{{ asset('general/img/intro.jpg') }}" alt="">
          </div>

          <div class="col-lg-6 content">
            <h2>Fasilitas</h2>
            <h3>Dengan mengikuti try out yang diadakan Masuk PTN, kamu akan mendapatkan:</h3>

            <ul>
              <li><i class="ion-android-checkmark-circle"></i> Alat Tulis</li>
              <li><i class="ion-android-checkmark-circle"></i> Soal SBMPTN semirip mungkin dengan aslinya</li>
              <li><i class="ion-android-checkmark-circle"></i> Hasil Ujian akan diberitahukan secara online </li>
              <li><i class="ion-android-checkmark-circle"></i> Sertifikat</li>
              <li><i class="ion-android-checkmark-circle"></i> Pembahasan Soal</li>
            </ul>

          </div>
        </div>

      </div>
    </section>
    <!-- #about -->

    <!--==========================
      Services Section
    ============================-->
    <section id="services">
      <div class="container">
        <div class="section-header">
          <h2>Lokasi Pelaksanaan</h2>
          <p></p>
        </div>

        <div class="row">
          <div class="col-lg-6">
            <div class="box wow fadeInRight">
              <div class="icon"><i class="fa fa-picture-o"></i></div>
              <h4 class="title"><a href="">Surabaya</a></h4>
              <p class="description">GOR Universitas PGRI Adi Buana<br>01 Februari 2019</p>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="box wow fadeInRight" data-wow-delay="0.2s">
              <div class="icon"><i class="fa fa-map"></i></div>
              <h4 class="title"><a href="">Yogyakarta</a></h4>
              <p class="description">Jl. Babarsari No. 2 Caturnunggal Depok Sleman Daerah Istimewa Yogyakartal<br>01 Desember 2018</p>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="box wow fadeInLeft">
              <div class="icon"><i class="fa fa-bar-chart"></i></div>
              <h4 class="title"><a href="">DKI Jakarta</a></h4>
              <p class="description">Jl. Rasuna Said Kav.C No.22, Setiabudi, Kota Jakarta Selatan<br> 01 September 2018</p>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="box wow fadeInLeft" data-wow-delay="0.2s">
              <div class="icon"><i class="fa fa-shopping-bag"></i></div>
              <h4 class="title"><a href="">Bandung</a></h4>
              <p class="description">Jl. P.H.H. Mustofa No. 31,Neglasari Kota Bandung<br>01 Januari 2019</p>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="box wow fadeInRight" data-wow-delay="0.2s">
              <div class="icon"><i class="fa fa-map"></i></div>
              <h4 class="title"><a href="">Semarang</a></h4>
              <p class="description">Jl. Kendeng V, Bendan Ngisor, Kota Semarang<br>01 November 2018</p>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="box wow fadeInRight" data-wow-delay="0.2s">
              <div class="icon"><i class="fa fa-map"></i></div>
              <h4 class="title"><a href="">Malang</a></h4>
              <p class="description">Jl. Tugu No.1 Klojen, Kota Malang<br>01 Oktober 2018</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- #services -->
    <section id="services">
      <div class="container">
        <div class="section-header">
          <h2>Langkah Pendaftaran</h2>
          <p></p>
        </div>
      </div>
    </section>
    <!--==========================
      Our Portfolio Section
    ============================-->
    <section id="portfolio" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2>Galeri</h2>
          <p></p>
        </div>
      </div>

      <div class="container-fluid">
        <div class="row no-gutters">

          <div class="col-lg-3 col-md-4">
            <div class="portfolio-item wow fadeInUp">
              <a href="{{ asset('front/img/portfolio/1.jpg') }}" class="portfolio-popup">
                <img src="{{ asset('front/img/portfolio/1.jpg') }}" alt="">
                <div class="portfolio-overlay">
                  <div class="portfolio-info"><h2 class="wow fadeInUp">Galeri 1</h2></div>
                </div>
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="portfolio-item wow fadeInUp">
              <a href="{{ asset('front/img/portfolio/2.jpg') }}" class="portfolio-popup">
                <img src="{{ asset('front/img/portfolio/2.jpg') }}" alt="">
                <div class="portfolio-overlay">
                  <div class="portfolio-info"><h2 class="wow fadeInUp">Galeri 2</h2></div>
                </div>
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="portfolio-item wow fadeInUp">
              <a href="{{ asset('front/img/portfolio/3.jpg') }}" class="portfolio-popup">
                <img src="{{ asset('front/img/portfolio/3.jpg') }}" alt="">
                <div class="portfolio-overlay">
                  <div class="portfolio-info"><h2 class="wow fadeInUp">Galeri 3</h2></div>
                </div>
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="portfolio-item wow fadeInUp">
              <a href="{{ asset('front/img/portfolio/4.jpg') }}" class="portfolio-popup">
                <img src="{{ asset('front/img/portfolio/4.jpg') }}" alt="">
                <div class="portfolio-overlay">
                  <div class="portfolio-info"><h2 class="wow fadeInUp">Galeri 4</h2></div>
                </div>
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="portfolio-item wow fadeInUp">
              <a href="{{ asset('front/img/portfolio/5.jpg') }}" class="portfolio-popup">
                <img src="{{ asset('front/img/portfolio/5.jpg') }}" alt="">
                <div class="portfolio-overlay">
                  <div class="portfolio-info"><h2 class="wow fadeInUp">Galeri 5</h2></div>
                </div>
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="portfolio-item wow fadeInUp">
              <a href="{{ asset('front/img/portfolio/6.jpg') }}" class="portfolio-popup">
                <img src="{{ asset('front/img/portfolio/6.jpg') }}" alt="">
                <div class="portfolio-overlay">
                  <div class="portfolio-info"><h2 class="wow fadeInUp">Galeri 6</h2></div>
                </div>
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="portfolio-item wow fadeInUp">
              <a href="{{ asset('front/img/portfolio/7.jpg') }}" class="portfolio-popup">
                <img src="{{ asset('front/img/portfolio/7.jpg') }}" alt="">
                <div class="portfolio-overlay">
                  <div class="portfolio-info"><h2 class="wow fadeInUp">Galeri 7</h2></div>
                </div>
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="portfolio-item wow fadeInUp">
              <a href="{{ asset('front/img/portfolio/8.jpg') }}" class="portfolio-popup">
                <img src="{{ asset('front/img/portfolio/8.jpg') }}" alt="">
                <div class="portfolio-overlay">
                  <div class="portfolio-info"><h2 class="wow fadeInUp">Galeri 8</h2></div>
                </div>
              </a>
            </div>
          </div>

        </div>

      </div>
    </section><!-- #portfolio -->
    <!--==========================
      Testimonials Section
    ============================-->
    <section id="testimonials" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2>Artikel</h2>
          <p></p>
        </div>
        <div class="row">
          @foreach($artikel as $d)
          <div class="col-sm-3">
            <div class="img-holder" style="height: 200px; overflow: hidden;">
              <img src="{{ asset('front/img/about-img.jpg') }}" style="width: 100%">
            </div>
            <a href="{{ url('article/', $d->url) }}" style="font-weight: bold; text-align: center;">{{ $d->judul }}</a>
          </div>
          @endforeach
        </div>
      </div>
    </section><!-- #testimonials -->

    <!--==========================
      Call To Action Section
    ============================-->
    <section id="call-to-action" class="wow fadeInUp">
      <div class="container">
        <div class="row">
          <div class="col-lg-9 text-center text-lg-left">
            <h3 class="cta-title" style="margin-top: 20px">Daftarkan dirimu sekarang Juga !!!</h3>
            <p class="cta-text"> </p>
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a class="cta-btn align-middle" href="#">Daftar Sekarang</a>
          </div>
        </div>

      </div>
    </section><!-- #call-to-action -->

  </main>
@endsection