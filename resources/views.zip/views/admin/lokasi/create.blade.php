@extends('layouts.parent_admin')

@section('content')
<div>
  <section class="content">
    <div class="row">
      <div class="col-xs-12">

        <div class="box" style="overflow:auto">
          <div class="box-header">
            @if (isset($data['lokasi']))
            <h3 class="box-title">
              Edit Lokasi
            </h3>
            @else
            <h3 class="box-title">
              Tambah Lokasi
            </h3>
            @endif
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            @if (isset($data['lokasi']))
            <?php
            $lokasi = $data['lokasi'];
            ?>
            <form action="{{ route('lokasi.update', $lokasi->id) }}" method="post">
            @else
            <form action="{{ url('lokasi/create') }}" method="post">
            @endif
              {!! csrf_field() !!}
              <div class="form-group">
                <label>Nama</label>
                @if(isset($lokasi->name))
                <input value="{{ $lokasi->name }}" type="text" class="form-control col-sm-12" name="name">
                @else
                <input type="text" class="form-control col-sm-12" name="name">
                @endif
              </div> 
              <input type="submit" class="btn btn-success col-sm-6 col-sm-offset-3">
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

@endsection