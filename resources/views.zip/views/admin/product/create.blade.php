@extends('layouts.parent_admin')

@section('content')
<div>
  <section class="content">
    <div class="row">
      <div class="col-xs-12">

        <div class="box" style="overflow:auto">
          <div class="box-header">
            @if (isset($data['product']))
            <h3 class="box-title">
              Edit Produk
            </h3>
            @else
            <h3 class="box-title">
              Tambah Produk
            </h3>
            @endif
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            @if (isset($data['product']))
            <?php
            $product = $data['product'];
            ?>
            <form action="{{ route('product.update', $product->id) }}" method="post">
            @else
            <form action="{{ url('product/create') }}" method="post">
            @endif
              {!! csrf_field() !!}
              <div class="form-group">
                <label>Nama</label>
                @if(isset($product->name))
                <input value="{{ $product->name }}" type="text" class="form-control" name="name">
                @else
                <input type="text" name="name" class='form-control'>
                @endif
              </div> 
              <div class="form-group">
                <label>Deskripsi</label>
                @if(isset($product->desc))
                <textarea class="form-control col-sm-12" name="desc">{{ $product->desc }}</textarea>
                @else
                <textarea class="form-control col-sm-12" name="desc"></textarea>
                @endif
              </div> 
              <div class="form-group">
                <label>Bundel Jumlah Peserta</label>
                @if(isset($product->jumlah_peserta))
                <input value="{{ $product->jumlah_peserta }}"  type="number" class="form-control" name="jumlah_peserta" />
                @else
                <input type="number" class="form-control" name="jumlah_peserta" />
                @endif
              </div> 
              <div class="form-group">
                <label>Diskon</label>
                @if(isset($product->diskon))
                <input value="{{ $product->diskon }}" type="number" class="form-control" name="diskon" placeholder="dalam (%)"/>
                @else
                <input type="number" class="form-control" name="diskon" placeholder="dalam (%)"/>
                @endif
              </div> 
              <div class="form-group">
                <label>Berlaku Sampai</label>
                @if(isset($product->berlaku_sampai))
                <input value="{{ $product->berlaku_sampai }}" name="berlaku_sampai" class='date form-control datepicker'>
                @else
                <input name="berlaku_sampai" class='date form-control datepicker'>
                @endif
              </div> 
              <div class="form-group">
                <label>Tryout</label>
                <select class="form-control select2" name="id_tryout">
                  <optgroup label="Select Tryout" >
                    @foreach($data['tryout'] as $p)
                    <option value="{{ $p->id }}"
                      <?php
                      if (isset($product->id_tryout)){
                        if ($product->id_tryout == $p->id)
                          echo "selected='selected'";
                      }
                      ?>>{{ $p->deskripsi }}</option>
                    @endforeach
                  </optgroup>
                </select>
              </div> 
              <input type="submit" class="btn btn-success col-sm-6 col-sm-offset-3">
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

@endsection