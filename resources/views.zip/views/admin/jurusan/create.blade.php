@extends('layouts.parent_admin')

@section('content')
<div>
  <section class="content">
    <div class="row">
      <div class="col-xs-12">

        <div class="box" style="overflow:auto">
          <div class="box-header">
            @if (isset($data['jurusan']))
            <h3 class="box-title">
              Edit Jurusan
            </h3>
            @else
            <h3 class="box-title">
              Tambah Jurusan
            </h3>
            @endif
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            @if (isset($data['jurusan']))
            <?php
            $jurusan = $data['jurusan'];
            ?>
            <form action="{{ route('jurusan.update', $jurusan->id) }}" method="post">
            @else
            <form action="{{ url('jurusan/create') }}" method="post">
            @endif
              {!! csrf_field() !!}
              <div class="form-group">
                <label>Nama</label>
                @if(isset($jurusan->name))
                <input value="{{ $jurusan->name }}" type="text" class="form-control col-sm-12" name="name">
                @else
                <input type="text" class="form-control col-sm-12" name="name">
                @endif
              </div> 
              <div class="form-group">
                <label>Deskripsi</label>
                @if(isset($jurusan->desc))
                <textarea class="form-control col-sm-12" name="desc">{{ $jurusan->desc }}</textarea>
                @else
                <textarea class="form-control col-sm-12" name="desc"></textarea>
                @endif
              </div> 
              <input type="submit" class="btn btn-success col-sm-6 col-sm-offset-3">
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

@endsection